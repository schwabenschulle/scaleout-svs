# Copyright (c) '2015' Cisco Systems, Inc. All Rights Reserved

from cobra.mit.xmlcodec import parseXMLError, fromXMLStr, fromXMLStream, toXMLStr, _toXMLStr, _createMo